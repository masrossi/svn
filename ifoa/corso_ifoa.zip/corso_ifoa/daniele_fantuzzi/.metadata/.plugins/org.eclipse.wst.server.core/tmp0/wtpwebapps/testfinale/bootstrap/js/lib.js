function display(where,what)
{
		var x=document.getElementById(where);
		x.innerHTML = what;
}