package it.ifoa.testfinale.constants;

public class TestFinaleConstants {

	public static final String DB_CONNETCION_STRING = "jdbc:mysql://localhost/testfinale?user=root&password=";
	public static final String MYSQL_DRIVER_NAME = "com.mysql.jdbc.Driver";
}
