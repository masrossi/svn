package it.ifoa.testfinale.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import it.ifoa.testfinale.constants.TestFinaleConstants;
import it.ifoa.testfinale.exception.TestFinaleException;
import it.ifoa.testfinale.model.Post;
import it.ifoa.testfinale.model.Risposta;
import it.ifoa.testfinale.model.Utente;

public class PostUtil {
	
	public static void main(String[] args) {
		try {
			List<Post> posts = getPosts(null, null);
			for (Post post : posts) {
				System.out.println(post.getTitolo());
			}
			
			Utente utente = UtenteUtils.getUtente("andrea", "password");
			List<Post> postsUtente = getPosts(null, utente);
			for (Post post : postsUtente) {
				System.out.println(post.getTitolo());
			}
			
			List<Post> postsUtenteLimit = getPosts(0, utente);
			for (Post post : postsUtenteLimit) {
				System.out.println(post.getTitolo());
			}
			
			Post p = getPost(1);
			System.out.println(p.getTitolo());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	public static List<Post> getPosts(Integer limit, Utente u) throws TestFinaleException {

		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		List<Post> res = new ArrayList<Post>();
		try {
			Class.forName(TestFinaleConstants.MYSQL_DRIVER_NAME).newInstance();
			conn = DriverManager.getConnection(TestFinaleConstants.DB_CONNETCION_STRING);
			String query = "SELECT post.id, post.titolo, post.testo, post.postdate, post.idutente, utenti.username FROM post JOIN utenti on post.idutente = utenti.id ";
			if(u != null) {
				query = query.concat("WHERE idutente = ?");
			}
			query = query.concat(" order by postdate DESC");
			if(limit != null) {
				query = query.concat(" limit "+limit);
			}
			stmt = conn.prepareStatement(query);
			if(u != null) {
				stmt.setInt(1, u.getId());
			}
			rs = stmt.executeQuery();
			
			while(rs.next()) {
				Post p = new Post();
				p.setId(rs.getInt(1));
				p.setTitolo(rs.getString(2));
				p.setTesto(rs.getString(3));
				p.setPostdate(rs.getTimestamp(4));
				p.setIdUtente(rs.getInt(5));
				p.setAutore(rs.getString(6));
				res.add(p);
				
				
			}
		} catch (Exception ex) {
			throw new TestFinaleException(ex);
		} finally {
			try {
				if(rs != null)
					rs.close();
				if(stmt != null)
					stmt.close();
				if(conn != null)
					conn.close();
			} catch (SQLException e) {
				throw new TestFinaleException(e);
			}
		}
		return res;
	}
	
	public static Post getPost(Integer id) throws TestFinaleException {

		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			Class.forName(TestFinaleConstants.MYSQL_DRIVER_NAME).newInstance();
			conn = DriverManager.getConnection(TestFinaleConstants.DB_CONNETCION_STRING);
			String query = "SELECT post.id, post.titolo, post.testo, post.postdate, post.idutente, utenti.username FROM post JOIN utenti on post.idutente = utenti.id WHERE post.id = ?";
			stmt = conn.prepareStatement(query);
			stmt.setInt(1, id);
			rs = stmt.executeQuery();
			Post p = null;
			while(rs.next()) {
				p = new Post();
				p.setId(rs.getInt(1));
				p.setTitolo(rs.getString(2));
				p.setTesto(rs.getString(3));
				p.setPostdate(rs.getTimestamp(4));
				p.setIdUtente(rs.getInt(5));
				p.setAutore(rs.getString(6));
			}
			rs.close();
			stmt.close();
			
			if(p != null) {
				ArrayList<Risposta> risposte = new ArrayList<Risposta>();
				query = "SELECT risposte.id, risposte.idpost, risposte.idutente, risposte.testo, risposte.postdate, utenti.username FROM risposte JOIN utenti on risposte.idutente = utenti.id WHERE idpost = ? order by postdate DESC";
				stmt = conn.prepareStatement(query);
				stmt.setInt(1, p.getId());
				rs = stmt.executeQuery();
				while(rs.next()) {
					Risposta r = new Risposta();
					r.setId(rs.getInt(1));
					r.setIdPost(rs.getInt(2));
					r.setIdUtente(rs.getInt(3));
					r.setTesto(rs.getString(4));
					r.setPostdate(rs.getTimestamp(5));
					r.setAutore(rs.getString(6));
					risposte.add(r);
				}
				p.setRisposte(risposte);
			}
			
			return p;
		} catch (Exception ex) {
			throw new TestFinaleException(ex);
		} finally {
			try {
				if(rs != null)
					rs.close();
				if(stmt != null)
					stmt.close();
				if(conn != null)
					conn.close();
			} catch (SQLException e) {
				throw new TestFinaleException(e);
			}
		}
	}


	public static int insert(Post post) throws TestFinaleException {

		Connection conn = null;
		PreparedStatement stmt = null;
		int res = 0;
		try {
			Class.forName(TestFinaleConstants.MYSQL_DRIVER_NAME).newInstance();
			conn = DriverManager.getConnection(TestFinaleConstants.DB_CONNETCION_STRING);
			stmt = conn.prepareStatement("INSERT INTO post (titolo, testo, idutente) VALUES (?,?,?)");
			
			stmt.setString(1,post.getTitolo());
			stmt.setString(2, post.getTesto());
			stmt.setInt(3, post.getIdUtente());
			res = stmt.executeUpdate();
			
		} catch (Exception ex) {
			throw new TestFinaleException(ex);
		} finally {
			try {
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				throw new TestFinaleException(e);
			}
		}
		return res;
	}


	public static int insert(Risposta r) throws TestFinaleException {

		Connection conn = null;
		PreparedStatement stmt = null;
		int res = 0;
		try {
			Class.forName(TestFinaleConstants.MYSQL_DRIVER_NAME).newInstance();
			conn = DriverManager.getConnection(TestFinaleConstants.DB_CONNETCION_STRING);
			stmt = conn.prepareStatement("INSERT INTO risposte (idpost, testo, idutente) VALUES (?,?,?)");
			
			stmt.setInt(1, r.getIdPost());
			stmt.setString(2, r.getTesto());
			stmt.setInt(3, r.getIdUtente());
			res = stmt.executeUpdate();
			
		} catch (Exception ex) {
			throw new TestFinaleException(ex);
		} finally {
			try {
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				throw new TestFinaleException(e);
			}
		}
		return res;
	}
}
