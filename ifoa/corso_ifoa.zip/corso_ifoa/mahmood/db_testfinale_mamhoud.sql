/*
SQLyog Community v12.4.3 (64 bit)
MySQL - 5.7.17 : Database - testfinale
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`testfinale` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `testfinale`;

/*Table structure for table `post` */

DROP TABLE IF EXISTS `post`;

CREATE TABLE `post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titolo` varchar(100) NOT NULL,
  `testo` text NOT NULL,
  `postdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `idutente` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `autore` (`idutente`),
  CONSTRAINT `post_ibfk_1` FOREIGN KEY (`idutente`) REFERENCES `utenti` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

/*Data for the table `post` */

insert  into `post`(`id`,`titolo`,`testo`,`postdate`,`idutente`) values 
(1,'iPhone 6s','Ho acquistato da 6 mesi un iPhone 6s e la batteria dura meno di 4 ore!!','2017-06-22 10:14:12',1);
insert  into `post`(`id`,`titolo`,`testo`,`postdate`,`idutente`) values 
(2,'Huawei P9 Lite','Testato, ottimo rapporto q/p!','2017-06-22 11:54:00',2);
insert  into `post`(`id`,`titolo`,`testo`,`postdate`,`idutente`) values 
(3,'Nokia Lumia 920','Che ne pensate del Nokia Lumia 920?','2017-06-22 11:55:49',3);
insert  into `post`(`id`,`titolo`,`testo`,`postdate`,`idutente`) values 
(4,'Un post esageratamente lungo','Per testare se effettivamente funziona il metodo substring!\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc elit odio, imperdiet in fringilla convallis, scelerisque nec lacus. Nullam varius dictum metus, vitae tincidunt nisl tristique ac. Mauris eu augue vulputate, vestibulum mi vitae, hendrerit quam. Nam sollicitudin felis lorem, vitae gravida justo aliquam non. Quisque rutrum libero ac urna porttitor consectetur. Aenean non eros eu augue finibus aliquet nec viverra quam. Suspendisse aliquet dui in varius lacinia. Donec tempus, ligula ut elementum dapibus, nibh nisl placerat neque, sit amet euismod justo diam non velit. Curabitur eu neque at lectus porttitor imperdiet. Nam pulvinar, lacus mattis luctus fringilla, magna ligula tincidunt elit, vitae finibus enim dolor ut velit. Integer vehicula, nisl eu tempus pulvinar, neque est placerat nulla, rutrum consequat nulla neque vitae tortor. Praesent facilisis blandit eros, sed tincidunt sapien pharetra vel. Proin gravida quam ipsum. Aliquam sit amet massa urna. Vestibulum congue aliquet lectus, cursus rhoncus mi gravida nec. Sed vel ullamcorper eros.\r\n\r\nCras consectetur non odio dignissim faucibus. Nam vulputate justo quis pellentesque rhoncus. Vestibulum nisl magna, malesuada et mattis a, venenatis quis diam. Phasellus rhoncus egestas est, sit amet porta odio gravida tincidunt. Sed ut aliquet nibh. Aenean sed ligula faucibus, eleifend augue quis, malesuada velit. Mauris et elit at augue pulvinar feugiat.\r\n\r\nNunc imperdiet posuere lorem, non condimentum mi iaculis sed. Morbi placerat sapien eu arcu euismod mattis. Ut ut dictum nibh, id maximus justo. Praesent sem libero, eleifend ut gravida eget, luctus sed augue. Maecenas feugiat mi eu massa hendrerit placerat. Proin risus neque, fringilla id arcu ut, scelerisque molestie nulla. Curabitur porttitor semper risus sed volutpat. Nulla ut lacinia odio. Suspendisse id diam et metus tristique finibus. Aliquam a enim nulla. Nam nunc lacus, porttitor sit amet diam quis, egestas suscipit nunc. Nullam non congue enim, eget interdum elit. Pellentesque felis ex, tristique ut tortor at, mattis rutrum nunc. Maecenas vitae nibh eu nisi porttitor accumsan. Mauris commodo, purus eu tempor aliquet, sem purus pulvinar tortor, tincidunt maximus ex tellus quis ligula.','2017-06-22 12:23:41',1);
insert  into `post`(`id`,`titolo`,`testo`,`postdate`,`idutente`) values 
(5,'Samsung Galaxy S8','Samsung Galaxy S8 è uno smartphone Android con caratteristiche all\'avanguardia che lo rendono una scelta eccellente per ogni tipo di utilizzo, rappresentando uno dei migliori dispositivi mobili mai realizzati. Dispone di un grande display da 5.8 pollici e di una risoluzione da 2960x1440 pixel, fra le più elevate attualmente in circolazione. Le funzionalità offerte da questo Samsung Galaxy S8 sono innumerevoli e tutte al top di gamma. A cominciare dal modulo LTE 4G che permette un trasferimento dati e una navigazione in internet eccellente, passando per la connettività Wi-fi e il GPS. \nFotocamera da 12 megapixel. Lo spessore di 8mm è veramente contenuto e rende questo Samsung Galaxy S8 ancora più spettacolare. ','2017-06-22 12:25:17',3);
insert  into `post`(`id`,`titolo`,`testo`,`postdate`,`idutente`) values 
(6,'111','dddfsdfsdfs','2017-06-22 17:05:16',1);

/*Table structure for table `risposte` */

DROP TABLE IF EXISTS `risposte`;

CREATE TABLE `risposte` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idpost` int(11) NOT NULL,
  `idutente` int(11) NOT NULL,
  `testo` text NOT NULL,
  `postdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idpost` (`idpost`),
  KEY `idutente` (`idutente`),
  CONSTRAINT `risposte_ibfk_1` FOREIGN KEY (`idpost`) REFERENCES `post` (`id`),
  CONSTRAINT `risposte_ibfk_2` FOREIGN KEY (`idutente`) REFERENCES `utenti` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `risposte` */

insert  into `risposte`(`id`,`idpost`,`idutente`,`testo`,`postdate`) values 
(1,1,1,'risposta a aa','2017-06-22 11:43:28');
insert  into `risposte`(`id`,`idpost`,`idutente`,`testo`,`postdate`) values 
(2,1,1,'seconda risposta a aa','2017-06-22 11:51:47');
insert  into `risposte`(`id`,`idpost`,`idutente`,`testo`,`postdate`) values 
(3,1,1,'terza risposta','2017-06-22 11:53:33');
insert  into `risposte`(`id`,`idpost`,`idutente`,`testo`,`postdate`) values 
(4,3,1,'Stai scherzando??','2017-06-22 12:22:32');
insert  into `risposte`(`id`,`idpost`,`idutente`,`testo`,`postdate`) values 
(5,5,1,'...e quindi?','2017-06-22 12:25:41');
insert  into `risposte`(`id`,`idpost`,`idutente`,`testo`,`postdate`) values 
(6,5,1,'xxxx','2017-06-22 17:07:36');

/*Table structure for table `utenti` */

DROP TABLE IF EXISTS `utenti`;

CREATE TABLE `utenti` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(256) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `utenti` */

insert  into `utenti`(`id`,`username`,`password`,`email`) values 
(1,'andrea','password','andrea.previati@mobimentum.it');
insert  into `utenti`(`id`,`username`,`password`,`email`) values 
(2,'luca','password','luca@email.com');
insert  into `utenti`(`id`,`username`,`password`,`email`) values 
(3,'paolo','password','paolo@email.com');
insert  into `utenti`(`id`,`username`,`password`,`email`) values 
(4,'giovanni','password','giovanni@email.com');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
