package it.ifoa.testfinale.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import it.ifoa.testfinale.constants.TestFinaleConstants;
import it.ifoa.testfinale.exception.TestFinaleException;
import it.ifoa.testfinale.model.Utente;


public class UtenteUtils {

	public static Utente getUtente(String username, String password) throws TestFinaleException {

		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			Class.forName(TestFinaleConstants.MYSQL_DRIVER_NAME).newInstance();
			conn = DriverManager.getConnection(TestFinaleConstants.DB_CONNETCION_STRING);
			stmt = conn.prepareStatement("SELECT * FROM utenti where username = ? and password = ?");
			stmt.setString(1, username);
			stmt.setString(2, password);
			rs = stmt.executeQuery();
			
			while(rs.next()) {
				Utente u = new Utente();
				u.setId(rs.getInt(1));
				u.setUsername(rs.getString(2));
				return u;
			}
		} catch (Exception ex) {
			throw new TestFinaleException(ex);
		} finally {
			try {
				if(rs != null)
					rs.close();
				if(stmt != null)
					stmt.close();
				if(conn != null)
					conn.close();
			} catch (SQLException e) {
				throw new TestFinaleException(e);
			}
		}
		return null;
	}
	
	public static Utente getUtente(Integer idUtente) throws TestFinaleException {

		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			Class.forName(TestFinaleConstants.MYSQL_DRIVER_NAME).newInstance();
			conn = DriverManager.getConnection(TestFinaleConstants.DB_CONNETCION_STRING);
			stmt = conn.prepareStatement("SELECT * FROM utenti where id = ?");
			stmt.setInt(1, idUtente);
			rs = stmt.executeQuery();
			
			while(rs.next()) {
				Utente u = new Utente();
				u.setId(rs.getInt(1));
				u.setUsername(rs.getString(2));
				return u;
			}
		} catch (Exception ex) {
			throw new TestFinaleException(ex);
		} finally {
			try {
				if(rs != null)
					rs.close();
				if(stmt != null)
					stmt.close();
				if(conn != null)
					conn.close();
			} catch (SQLException e) {
				throw new TestFinaleException(e);
			}
		}
		return null;
	}
	
}
