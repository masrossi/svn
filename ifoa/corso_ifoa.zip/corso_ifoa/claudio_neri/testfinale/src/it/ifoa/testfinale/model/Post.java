package it.ifoa.testfinale.model;

import java.sql.Timestamp;
import java.util.List;

public class Post {

	private Integer id;
	private String titolo;
	private String testo;
	private Timestamp postdate;
	private Integer idUtente;
	private List<Risposta> risposte;
	private String autore;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getTitolo() {
		return titolo;
	}
	public void setTitolo(String titolo) {
		this.titolo = titolo;
	}
	public String getTesto() {
		return testo;
	}
	public void setTesto(String testo) {
		this.testo = testo;
	}
	public Timestamp getPostdate() {
		return postdate;
	}
	public void setPostdate(Timestamp postdate) {
		this.postdate = postdate;
	}
	public Integer getIdUtente() {
		return idUtente;
	}
	public void setIdUtente(Integer idUtente) {
		this.idUtente = idUtente;
	}
	public List<Risposta> getRisposte() {
		return risposte;
	}
	public void setRisposte(List<Risposta> risposte) {
		this.risposte = risposte;
	}
	public String getAutore() {
		return autore;
	}
	public void setAutore(String autore) {
		this.autore = autore;
	}
	
}
