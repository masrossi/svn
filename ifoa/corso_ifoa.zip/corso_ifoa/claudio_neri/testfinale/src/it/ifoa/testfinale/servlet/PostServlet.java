package it.ifoa.testfinale.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import it.ifoa.testfinale.exception.TestFinaleException;
import it.ifoa.testfinale.model.Post;
import it.ifoa.testfinale.model.Risposta;
import it.ifoa.testfinale.model.Utente;
import it.ifoa.testfinale.util.PostUtil;
import it.ifoa.testfinale.util.UtenteUtils;

/**
 * Servlet implementation class PostServlet
 */
@WebServlet("/PostServlet")
public class PostServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PostServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idPost = request.getParameter("idPost");
		if(idPost != null && !idPost.isEmpty()) {
			Post post;
			try {
				post = PostUtil.getPost(Integer.parseInt(idPost));
			} catch (NumberFormatException | TestFinaleException e) {
				throw new ServletException(e);
			}
			request.setAttribute("post", post);
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/post.jsp");
			dispatcher.forward(request, response);
		} else {
			String idUtente = request.getParameter("idUtente");
			if(idUtente != null && !idUtente.isEmpty()) {
				try {
					Utente u = UtenteUtils.getUtente(Integer.parseInt(idUtente));
					List<Post> posts = PostUtil.getPosts(null, u);
					request.setAttribute("posts", posts);
				} catch (NumberFormatException | TestFinaleException e) {
					throw new ServletException(e);
				}
				RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/auth/myposts.jsp");
				dispatcher.forward(request, response);
			} else {
				String limit = request.getParameter("limit");
				List<Post> posts = null;
				try {
					if(limit != null && !limit.isEmpty()) {
						posts = PostUtil.getPosts(Integer.parseInt(limit), null);
					} else {
						posts = PostUtil.getPosts(null, null);
					}
					request.setAttribute("posts", posts);
					RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/home.jsp");
					dispatcher.forward(request, response);
				} catch (NumberFormatException | TestFinaleException e) {
					throw new ServletException(e);
				}
			}
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idPost = request.getParameter("idPost");
		Utente loggedUser = (Utente)request.getSession().getAttribute("loggedUser");
		if(idPost != null && !idPost.isEmpty()) {
			String testo = request.getParameter("testo");
			Risposta r = new Risposta();
			r.setIdPost(Integer.parseInt(idPost));
			r.setIdUtente(loggedUser.getId());
			r.setTesto(testo);
			try {
				int res = PostUtil.insert(r);
			} catch (TestFinaleException e) {
				throw new ServletException(e);
			}
			response.sendRedirect(request.getContextPath()+"/PostServlet?idPost="+idPost);
		} else {
			String titolo = request.getParameter("titolo");
			String testo = request.getParameter("testo");
			
			
			Post post = new Post();
			post.setTitolo(titolo);
			post.setTesto(testo);
			post.setIdUtente(loggedUser.getId());
			
			
			try {
				int res = PostUtil.insert(post);
			} catch (TestFinaleException e) {
				throw new ServletException(e);
			}
			response.sendRedirect(request.getContextPath()+"/PostServlet?idUtente="+loggedUser.getId());
		}
		
		
	}

}
