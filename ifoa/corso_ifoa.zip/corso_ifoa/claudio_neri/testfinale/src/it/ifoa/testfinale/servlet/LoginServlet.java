package it.ifoa.testfinale.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import it.ifoa.testfinale.exception.TestFinaleException;
import it.ifoa.testfinale.model.Utente;
import it.ifoa.testfinale.util.UtenteUtils;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String u = request.getParameter("username");
		String p = request.getParameter("password");
		Utente utente;
		try {
			utente = UtenteUtils.getUtente(u, p);
		} catch (TestFinaleException e) {
			throw new ServletException(e);
		}
		if(utente == null) {
			request.setAttribute("msg", "utente non trovato");
			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/login.jsp");
			dispatcher.forward(request, response);
		} else {
			request.getSession().setAttribute("loggedUser", utente);
			response.sendRedirect("PostServlet?idUtente="+utente.getId());
		}
	}

}
