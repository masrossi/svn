package it.ifoa.testfinale.exception;

public class TestFinaleException extends Exception {

	public TestFinaleException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public TestFinaleException(String arg0) {
		super(arg0);
	}

	public TestFinaleException(Throwable arg0) {
		super(arg0);
	}

	
}
