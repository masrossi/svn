/*
SQLyog Community v12.4.3 (64 bit)
MySQL - 5.7.17 : Database - testfinale
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`testfinale` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `testfinale`;

/*Table structure for table `post` */

DROP TABLE IF EXISTS `post`;

CREATE TABLE `post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titolo` varchar(100) NOT NULL,
  `testo` text NOT NULL,
  `postdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `idutente` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `autore` (`idutente`),
  CONSTRAINT `post_ibfk_1` FOREIGN KEY (`idutente`) REFERENCES `utenti` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `post` */

insert  into `post`(`id`,`titolo`,`testo`,`postdate`,`idutente`) values 
(1,'iPhone 6s','Ho acquistato da 6 mesi un iPhone 6s e la batteria dura meno di 4 ore!!','2017-06-22 10:14:12',1);
insert  into `post`(`id`,`titolo`,`testo`,`postdate`,`idutente`) values 
(2,'Huawei P9 Lite','Testato, ottimo rapporto q/p!','2017-06-22 11:54:00',2);
insert  into `post`(`id`,`titolo`,`testo`,`postdate`,`idutente`) values 
(3,'Nokia Lumia 920','Che ne pensate del Nokia Lumia 920?','2017-06-22 11:55:49',3);
insert  into `post`(`id`,`titolo`,`testo`,`postdate`,`idutente`) values 
(4,'Un post esageratamente lungo','Per testare se effettivamente funziona il metodo substring!\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc elit odio, imperdiet in fringilla convallis, scelerisque nec lacus. Nullam varius dictum metus, vitae tincidunt nisl tristique ac. Mauris eu augue vulputate, vestibulum mi vitae, hendrerit quam. Nam sollicitudin felis lorem, vitae gravida justo aliquam non. Quisque rutrum libero ac urna porttitor consectetur. Aenean non eros eu augue finibus aliquet nec viverra quam. Suspendisse aliquet dui in varius lacinia. Donec tempus, ligula ut elementum dapibus, nibh nisl placerat neque, sit amet euismod justo diam non velit. Curabitur eu neque at lectus porttitor imperdiet. Nam pulvinar, lacus mattis luctus fringilla, magna ligula tincidunt elit, vitae finibus enim dolor ut velit. Integer vehicula, nisl eu tempus pulvinar, neque est placerat nulla, rutrum consequat nulla neque vitae tortor. Praesent facilisis blandit eros, sed tincidunt sapien pharetra vel. Proin gravida quam ipsum. Aliquam sit amet massa urna. Vestibulum congue aliquet lectus, cursus rhoncus mi gravida nec. Sed vel ullamcorper eros.\r\n\r\nCras consectetur non odio dignissim faucibus. Nam vulputate justo quis pellentesque rhoncus. Vestibulum nisl magna, malesuada et mattis a, venenatis quis diam. Phasellus rhoncus egestas est, sit amet porta odio gravida tincidunt. Sed ut aliquet nibh. Aenean sed ligula faucibus, eleifend augue quis, malesuada velit. Mauris et elit at augue pulvinar feugiat.\r\n\r\nNunc imperdiet posuere lorem, non condimentum mi iaculis sed. Morbi placerat sapien eu arcu euismod mattis. Ut ut dictum nibh, id maximus justo. Praesent sem libero, eleifend ut gravida eget, luctus sed augue. Maecenas feugiat mi eu massa hendrerit placerat. Proin risus neque, fringilla id arcu ut, scelerisque molestie nulla. Curabitur porttitor semper risus sed volutpat. Nulla ut lacinia odio. Suspendisse id diam et metus tristique finibus. Aliquam a enim nulla. Nam nunc lacus, porttitor sit amet diam quis, egestas suscipit nunc. Nullam non congue enim, eget interdum elit. Pellentesque felis ex, tristique ut tortor at, mattis rutrum nunc. Maecenas vitae nibh eu nisi porttitor accumsan. Mauris commodo, purus eu tempor aliquet, sem purus pulvinar tortor, tincidunt maximus ex tellus quis ligula.','2017-06-22 12:23:41',1);
insert  into `post`(`id`,`titolo`,`testo`,`postdate`,`idutente`) values 
(5,'Samsung Galaxy S8','Samsung Galaxy S8 è uno smartphone Android con caratteristiche all\'avanguardia che lo rendono una scelta eccellente per ogni tipo di utilizzo, rappresentando uno dei migliori dispositivi mobili mai realizzati. Dispone di un grande display da 5.8 pollici e di una risoluzione da 2960x1440 pixel, fra le più elevate attualmente in circolazione. Le funzionalità offerte da questo Samsung Galaxy S8 sono innumerevoli e tutte al top di gamma. A cominciare dal modulo LTE 4G che permette un trasferimento dati e una navigazione in internet eccellente, passando per la connettività Wi-fi e il GPS. \nFotocamera da 12 megapixel. Lo spessore di 8mm è veramente contenuto e rende questo Samsung Galaxy S8 ancora più spettacolare. ','2017-06-22 12:25:17',3);
insert  into `post`(`id`,`titolo`,`testo`,`postdate`,`idutente`) values 
(6,'111','dddfsdfsdfs','2017-06-22 17:05:16',1);
insert  into `post`(`id`,`titolo`,`testo`,`postdate`,`idutente`) values 
(7,'CiccioPasticcio','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','2017-06-27 10:27:28',1);
insert  into `post`(`id`,`titolo`,`testo`,`postdate`,`idutente`) values 
(8,'prova','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi risus felis, dignissim ut eros ac, convallis scelerisque mauris. Integer nisi purus, sagittis quis ante non, rutrum porttitor tellus. Cras ultricies tempus efficitur. Donec tempus massa nisi, at cursus felis pharetra in. Nam vestibulum auctor ultrices. Sed pharetra, nibh vestibulum ultrices vestibulum, quam elit luctus nisl, at efficitur neque orci non dui. Integer pulvinar rutrum augue eget faucibus. Nunc vestibulum orci eu enim vulputate, vitae mattis nisi placerat. Ut magna risus, lobortis et velit et, ullamcorper pulvinar dui. Ut gravida, turpis vel consectetur cursus, justo turpis placerat nunc, ac lobortis nisl ipsum sed turpis. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.\r\n\r\nVestibulum efficitur, turpis vitae posuere vehicula, magna felis interdum nunc, at viverra mi nunc at odio. Cras leo tortor, iaculis eu ullamcorper at, feugiat eu nisl. Proin in sapien maximus, auctor sapien ac, viverra dui. Donec est elit, sollicitudin quis efficitur eu, ornare bibendum ipsum. Sed ac elementum lorem, eu laoreet leo. Vestibulum blandit pulvinar ante. Integer et faucibus lectus, ut placerat libero. Fusce eu lectus nisi. Sed nulla lacus, pulvinar molestie leo sed, gravida fringilla libero. Ut venenatis quis orci ut efficitur. Quisque id lobortis sem. Duis sed sollicitudin massa. Ut in lectus vestibulum, ornare diam a, fringilla nisi.\r\n\r\nPraesent nec rutrum mi. Praesent placerat semper nisl non tempor. Sed ut ante quis felis mollis lacinia faucibus eu mauris. Ut accumsan tempus turpis, et vulputate risus tincidunt tincidunt. Nullam ut massa eu ante tincidunt dictum a vitae libero. Nulla quis eros commodo tortor pellentesque viverra. Aenean condimentum erat nisi, sed tristique lorem posuere sed. Curabitur vehicula quis risus non volutpat.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla tincidunt tortor eu risus convallis, at lobortis dolor feugiat. Sed est arcu, maximus dignissim nulla egestas, lobortis tincidunt odio. Curabitur eu felis non tortor molestie rhoncus. Suspendisse id cursus turpis. Maecenas suscipit justo nec dictum scelerisque. Morbi imperdiet lacinia sem, ut faucibus magna dapibus quis. Curabitur elit erat, viverra at cursus in, finibus a orci. Donec vitae magna eu ex efficitur ultrices vel nec sem. Integer hendrerit ipsum eget dapibus rhoncus.\r\n\r\nDuis tempor sapien non nunc consectetur, nec sagittis neque imperdiet. Aenean justo sapien, tempor sed nisi ut, vestibulum blandit nisl. Ut nec fermentum orci, vel pharetra tortor. Aliquam sit amet congue nulla, vitae suscipit massa. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Phasellus id libero sollicitudin, venenatis felis quis, tincidunt enim. Curabitur vel venenatis arcu. Fusce condimentum faucibus velit, sit amet egestas nisi mollis a. Nam sollicitudin finibus elementum. Maecenas tempus ultricies mauris, et ullamcorper odio malesuada ut. Nam dapibus dui a mi tincidunt laoreet. Maecenas lobortis nisl eu erat ullamcorper feugiat. Vivamus a nulla viverra, fermentum ipsum vel, porta diam. Nunc viverra sed felis et fermentum.\r\n\r\nAenean semper nulla id urna euismod congue. Ut a maximus arcu, sit amet semper nibh. In hac habitasse platea dictumst. Suspendisse hendrerit eros risus, ac blandit eros aliquam a. Mauris dapibus.','2017-06-28 12:05:54',1);

/*Table structure for table `risposte` */

DROP TABLE IF EXISTS `risposte`;

CREATE TABLE `risposte` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idpost` int(11) NOT NULL,
  `idutente` int(11) NOT NULL,
  `testo` text NOT NULL,
  `postdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idpost` (`idpost`),
  KEY `idutente` (`idutente`),
  CONSTRAINT `risposte_ibfk_1` FOREIGN KEY (`idpost`) REFERENCES `post` (`id`),
  CONSTRAINT `risposte_ibfk_2` FOREIGN KEY (`idutente`) REFERENCES `utenti` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `risposte` */

insert  into `risposte`(`id`,`idpost`,`idutente`,`testo`,`postdate`) values 
(1,1,1,'risposta a aa','2017-06-22 11:43:28');
insert  into `risposte`(`id`,`idpost`,`idutente`,`testo`,`postdate`) values 
(2,1,1,'seconda risposta a aa','2017-06-22 11:51:47');
insert  into `risposte`(`id`,`idpost`,`idutente`,`testo`,`postdate`) values 
(3,1,1,'terza risposta','2017-06-22 11:53:33');
insert  into `risposte`(`id`,`idpost`,`idutente`,`testo`,`postdate`) values 
(4,3,1,'Stai scherzando??','2017-06-22 12:22:32');
insert  into `risposte`(`id`,`idpost`,`idutente`,`testo`,`postdate`) values 
(5,5,1,'...e quindi?','2017-06-22 12:25:41');
insert  into `risposte`(`id`,`idpost`,`idutente`,`testo`,`postdate`) values 
(6,5,1,'xxxx','2017-06-22 17:07:36');
insert  into `risposte`(`id`,`idpost`,`idutente`,`testo`,`postdate`) values 
(7,5,1,'bbb','2017-06-22 17:07:51');
insert  into `risposte`(`id`,`idpost`,`idutente`,`testo`,`postdate`) values 
(8,5,1,'SI MA COSTA TROPPO!!!','2017-06-27 10:26:33');

/*Table structure for table `utenti` */

DROP TABLE IF EXISTS `utenti`;

CREATE TABLE `utenti` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(256) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `utenti` */

insert  into `utenti`(`id`,`username`,`password`,`email`) values 
(1,'andrea','5f4dcc3b5aa765d61d8327deb882cf99','andrea.previati@mobimentum.it');
insert  into `utenti`(`id`,`username`,`password`,`email`) values 
(2,'luca','5f4dcc3b5aa765d61d8327deb882cf99','luca@email.com');
insert  into `utenti`(`id`,`username`,`password`,`email`) values 
(3,'paolo','5f4dcc3b5aa765d61d8327deb882cf99','paolo@email.com');
insert  into `utenti`(`id`,`username`,`password`,`email`) values 
(4,'giovanni','5f4dcc3b5aa765d61d8327deb882cf99','giovanni@email.com');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
